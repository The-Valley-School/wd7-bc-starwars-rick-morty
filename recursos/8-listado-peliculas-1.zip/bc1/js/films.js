const printFilms = () => {
    mainContainer.innerHTML = `
        <section class="section">
            <h3 class="section__title">FILMS</h3>
            <section class="section__container">
                <div class="card">
                    <h4 class="card__title"> LA AMENAZA FANTASMA </h4>
                    <img class="card__img" src="../assets/images/films/1.jpg">
                    <div class="card__info-container">
                        <p class="card__info-title"> EPISODE </p>
                        <p class="card__info"> III </p>
                        <p class="card__info-title"> DIRECTOR </p>
                        <p class="card__info"> Geroge Lucas </p>
                        <p class="card__info-title"> DATE </p>
                        <p class="card__info"> 1977-05-01 </p>
                        <a class="card__link" href="#"> +MORE DETAILS </a>
                    </div>
                </div> 
                
                <div class="card">
                    <h4 class="card__title"> LA AMENAZA FANTASMA </h4>
                    <img class="card__img" src="../assets/images/films/1.jpg">
                    <div class="card__info-container">
                        <p class="card__info-title"> EPISODE </p>
                        <p class="card__info"> III </p>
                        <p class="card__info-title"> DIRECTOR </p>
                        <p class="card__info"> Geroge Lucas </p>
                        <p class="card__info-title"> DATE </p>
                        <p class="card__info"> 1977-05-01 </p>
                        <a class="card__link" href="#"> +MORE DETAILS </a>
                    </div>
                </div> 

                <div class="card">
                    <h4 class="card__title"> LA AMENAZA FANTASMA </h4>
                    <img class="card__img" src="../assets/images/films/1.jpg">
                    <div class="card__info-container">
                        <p class="card__info-title"> EPISODE </p>
                        <p class="card__info"> III </p>
                        <p class="card__info-title"> DIRECTOR </p>
                        <p class="card__info"> Geroge Lucas </p>
                        <p class="card__info-title"> DATE </p>
                        <p class="card__info"> 1977-05-01 </p>
                        <a class="card__link" href="#"> +MORE DETAILS </a>
                    </div>
                </div> 

                <div class="card">
                    <h4 class="card__title"> LA AMENAZA FANTASMA </h4>
                    <img class="card__img" src="../assets/images/films/1.jpg">
                    <div class="card__info-container">
                        <p class="card__info-title"> EPISODE </p>
                        <p class="card__info"> III </p>
                        <p class="card__info-title"> DIRECTOR </p>
                        <p class="card__info"> Geroge Lucas </p>
                        <p class="card__info-title"> DATE </p>
                        <p class="card__info"> 1977-05-01 </p>
                        <a class="card__link" href="#"> +MORE DETAILS </a>
                    </div>
                </div> 
            </section>
        </section>
    `;
}